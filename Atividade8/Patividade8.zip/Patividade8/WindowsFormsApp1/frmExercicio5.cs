﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] NotasAlunos = new string[20, 10];

            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            string auxiliar;

            

            for (int i = 0; i < 19; i++) 
            {
                
                for (int j = 0; j < 9; j++) 
                {
                    auxiliar = Interaction.InputBox($"Digite a {j+1}° resposta do aluno {i + 1}",
                            "Entrada de Dados");

                    if (auxiliar.Length == 0 || !(auxiliar.ToUpper()=="A" || auxiliar.ToUpper() == "B"
                        || auxiliar.ToUpper() == "C" || auxiliar.ToUpper() == "D" || auxiliar.ToUpper() == "E"))
                    {
                        MessageBox.Show("Resposta Invalida!");
                        j--;
                    } else if (auxiliar.ToUpper() == gabarito[j]) 
                    {
                        lstbxNotas.Items.Add($"O Aluno: {i+1}. Acertou a Questão {j+1},Era {gabarito[j]} e " +
                            $"Escolheu {auxiliar.ToUpper()} ");
                    }
                    else
                    {
                        lstbxNotas.Items.Add($"O Aluno: {i + 1}. Errou a Questão {j + 1},Era {gabarito[j]} e " +
                            $"Escolheu {auxiliar.ToUpper()} ");
                    }
                }
            
            }



        }
    }
}
