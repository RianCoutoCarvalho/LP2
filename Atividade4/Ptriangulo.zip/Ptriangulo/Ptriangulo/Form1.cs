﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ValorA, ValorB, ValorC, Resultado;

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out ValorC) || (ValorC == 0))
            {
                MessageBox.Show("Formato/Numero Invalido");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ValorA > Math.Abs( ValorB - ValorC) && ValorA < ValorB + ValorC) &&(ValorB > Math.Abs(ValorA- ValorC) && ValorB<ValorA + ValorC) &&
            (ValorC > Math.Abs(ValorA - ValorB) && ValorC < ValorA + ValorB))
            {
                if (ValorA==ValorB && ValorA==ValorC && ValorB==ValorC) 
                {
                    MessageBox.Show("É um triangulo Equilatero");
                }
                else if (!(ValorA == ValorB) && !(ValorA == ValorC) && !(ValorB == ValorC)) 
                {
                    MessageBox.Show("É um triangulo Escaleno");
                }
                else
                {
                    MessageBox.Show("É um triangulo Isosceles");
                }
            }
            else
            {
                MessageBox.Show("Não é um triangulo");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out ValorB) || (ValorB == 0))
            {
                MessageBox.Show("Formato/Numero Invalido");
                txtValorB.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out ValorA) || (ValorA==0))
            {
                MessageBox.Show("Formato/Numero Invalido");
                txtValorA.Focus();
            }
        }
    }
}
