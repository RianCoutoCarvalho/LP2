﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInsiraNum = new System.Windows.Forms.TextBox();
            this.btnSomaNum = new System.Windows.Forms.Button();
            this.lblInserirNum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtInsiraNum
            // 
            this.txtInsiraNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInsiraNum.Location = new System.Drawing.Point(288, 176);
            this.txtInsiraNum.Name = "txtInsiraNum";
            this.txtInsiraNum.Size = new System.Drawing.Size(194, 30);
            this.txtInsiraNum.TabIndex = 0;
            // 
            // btnSomaNum
            // 
            this.btnSomaNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomaNum.Location = new System.Drawing.Point(288, 258);
            this.btnSomaNum.Name = "btnSomaNum";
            this.btnSomaNum.Size = new System.Drawing.Size(194, 82);
            this.btnSomaNum.TabIndex = 1;
            this.btnSomaNum.Text = "Somar Numero";
            this.btnSomaNum.UseVisualStyleBackColor = true;
            this.btnSomaNum.Click += new System.EventHandler(this.btnSomaNum_Click);
            // 
            // lblInserirNum
            // 
            this.lblInserirNum.AutoSize = true;
            this.lblInserirNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInserirNum.Location = new System.Drawing.Point(320, 100);
            this.lblInserirNum.Name = "lblInserirNum";
            this.lblInserirNum.Size = new System.Drawing.Size(133, 25);
            this.lblInserirNum.TabIndex = 2;
            this.lblInserirNum.Text = "Insira Numero";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblInserirNum);
            this.Controls.Add(this.btnSomaNum);
            this.Controls.Add(this.txtInsiraNum);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInsiraNum;
        private System.Windows.Forms.Button btnSomaNum;
        private System.Windows.Forms.Label lblInserirNum;
    }
}