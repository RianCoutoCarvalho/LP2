﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        

        private void btnConfPalindromo_Click(object sender, EventArgs e)
        {
         
            string Frase = txtInsiraFrase.Text.ToLower();
            string FraseNorm = Frase.Replace(" ", "");
            
            char[] FraseInv = FraseNorm.ToCharArray();
            Array.Reverse(FraseInv);

            
            if (string.Compare(FraseNorm, new string (FraseInv)) == 0)
            {
                MessageBox.Show("É um palindromo");
            }
            else
            {
                MessageBox.Show("Não é um palindromo");
            }

        }
    }
}
