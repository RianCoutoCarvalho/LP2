﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    cont++;
                }
                    
            }
            MessageBox.Show("Quantidade de Espaços em Branco é: "+cont);
        }

        private void btnQtdeR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (c=='R')
                {
                    cont++;
                }

            }
            MessageBox.Show("Quantidade de Letras R é : " + cont);
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int i,cont=0;

            for (i = rchtxtFrase.TextLength-1; i > 0; i--) 
            {
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i-1])
                {
                    cont++;
                }
            }
            MessageBox.Show("Quantidade de Letras Pares é: "+cont);
        }
    }
}
