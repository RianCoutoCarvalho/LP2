﻿namespace PLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInserirFrase = new System.Windows.Forms.Label();
            this.btnConfPalindromo = new System.Windows.Forms.Button();
            this.txtInsiraFrase = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblInserirFrase
            // 
            this.lblInserirFrase.AutoSize = true;
            this.lblInserirFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInserirFrase.Location = new System.Drawing.Point(225, 65);
            this.lblInserirFrase.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInserirFrase.Name = "lblInserirFrase";
            this.lblInserirFrase.Size = new System.Drawing.Size(82, 17);
            this.lblInserirFrase.TabIndex = 5;
            this.lblInserirFrase.Text = "Insira Frase";
            // 
            // btnConfPalindromo
            // 
            this.btnConfPalindromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfPalindromo.Location = new System.Drawing.Point(204, 168);
            this.btnConfPalindromo.Margin = new System.Windows.Forms.Padding(2);
            this.btnConfPalindromo.Name = "btnConfPalindromo";
            this.btnConfPalindromo.Size = new System.Drawing.Size(129, 53);
            this.btnConfPalindromo.TabIndex = 4;
            this.btnConfPalindromo.Text = "Conferir Palindromo";
            this.btnConfPalindromo.UseVisualStyleBackColor = true;
            this.btnConfPalindromo.Click += new System.EventHandler(this.btnConfPalindromo_Click);
            // 
            // txtInsiraFrase
            // 
            this.txtInsiraFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInsiraFrase.Location = new System.Drawing.Point(204, 114);
            this.txtInsiraFrase.Margin = new System.Windows.Forms.Padding(2);
            this.txtInsiraFrase.MaxLength = 50;
            this.txtInsiraFrase.Name = "txtInsiraFrase";
            this.txtInsiraFrase.Size = new System.Drawing.Size(131, 23);
            this.txtInsiraFrase.TabIndex = 3;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 317);
            this.Controls.Add(this.lblInserirFrase);
            this.Controls.Add(this.btnConfPalindromo);
            this.Controls.Add(this.txtInsiraFrase);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInserirFrase;
        private System.Windows.Forms.Button btnConfPalindromo;
        private System.Windows.Forms.TextBox txtInsiraFrase;
    }
}