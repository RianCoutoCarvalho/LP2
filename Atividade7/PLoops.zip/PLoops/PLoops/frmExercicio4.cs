﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }


        double Salario, B = 0, C = 0, D = 0, Prod, Grat,SalBrut;

        private void btnSalBrut_Click(object sender, EventArgs e)
        {
            if (Prod >= 150)
            {
                D = 1;
                C = 1;
                B = 1;
            }
            else if (Prod >= 120)
            {
                C = 1;
                B = 1;
            }
            else if (Prod >= 100)
            {
                B = 1;
            }

            SalBrut = Salario + Salario * (0.05 * B + 0.1 * C + 0.1 * D) + Grat;

            if (SalBrut >= 7000)
            {
                if (!(Grat != 0 && Prod >= 150))
                {
                    SalBrut = 7000;

                }
            }

            MessageBox.Show("Salario Bruto: " + SalBrut.ToString());
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out Grat))
            {
                MessageBox.Show("Numero Invalido!");
                txtGratificacao.Focus();
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out Salario))
            {
                MessageBox.Show("Numero Invalido!");
                txtSalario.Focus();
            }
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtProducao.Text, out Prod))
            {
                MessageBox.Show("Numero Invalido!");
                txtProducao.Focus();
            }
        }

        
    }
}
