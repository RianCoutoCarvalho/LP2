﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] VendaNote = new double[2, 3];

            string auxiliar = "";

            double QtdeNote = 0;

            double QtdeGeral = 0;

            int x = 0;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($" Insira valor do {j + 1}° notebook da loja {i + 1}",
                        "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out VendaNote[i, j]) ||
                        VendaNote[i, j] < 0)
                    {
                        MessageBox.Show("Valor Invalido! \n Tente Novamente");
                        j--;
                    }
                    else
                    {
                        QtdeNote += VendaNote[i, j];
                        QtdeGeral += VendaNote[i, j];
                        x++;
                        lstbxResultado.Items.Add($"NoteBook: {i + 1} Loja {j + 1} {String.Format("{0:C2}", VendaNote[i, j])}");
                    }
                }
                {

                    

                    lstbxResultado.Items.Add($"Media do notebook {i + 1}°: {String.Format("{0:C2}", QtdeNote / 3)}");
                    lstbxResultado.Items.Add("");

                    QtdeNote = 0;
                }
                
            }
            lstbxResultado.Items.Add($"Media Geral dos Computadores: {String.Format("{0:C2}", QtdeGeral / x)}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            
        }
    }
}
