﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void btnInserir1no2_Click(object sender, EventArgs e)
        {
            string Palavra2 = txtPalavra2.Text;
            int lenght = Palavra2.Length;
            Palavra2 = Palavra2.Insert(lenght / 2, txtPalavra1.Text);
            MessageBox.Show(Palavra2);

        }

        private void btnInserirAsterisco_Click(object sender, EventArgs e)
        {
            string Palavra1 = txtPalavra1.Text;
            int lenght = Palavra1.Length;
            Palavra1 = Palavra1.Insert(lenght / 2, "**");

            MessageBox.Show(Palavra1);
        }
    }
}
