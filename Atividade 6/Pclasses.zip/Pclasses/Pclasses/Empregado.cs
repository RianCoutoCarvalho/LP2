﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
     abstract internal class Empregado
    {
        private int matricula;
        private String nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado 
        { 
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public virtual int TempoTrabaho()
        {
            TimeSpan span =
            DateTime.Today.Subtract(dataEntradaEmpresa);
            return (span.Days);
        }

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado");
        }

        public abstract double SalarioBruto();

    }
}
